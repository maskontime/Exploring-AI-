# Assignment 1: Exploring AI with Creativity  

## Brand: Maskon – Wear Your Confidence  

This repository contains my submission for **Assignment 1**.  
The project explores AI-powered branding, creative design, and monetization strategies, applied to my fashion brand **Maskon**, which sells high-quality men’s suits.  

---

## 📌 Project Structure
- **phase1.md** → Branding & Business Setup  
- **phase2.md** → AI-Generated Design & Marketing Content  
- **phase3.md** → Client Outreach & Monetization  

---

## 🔹 Brand Summary
**Maskon** is a modern fashion brand dedicated to men’s suits.  
- **Tagline:** *Wear Your Confidence*  
- **Mission:** To empower men to express themselves through timeless, AI-inspired fashion.  

---

## 🔹 Key Deliverables
### Phase 1: Branding & Business Setup
- Business name, tagline, and mission.  
- Compelling brand story.  
- Canva logo design prompts.  

### Phase 2: AI-Generated Design & Marketing
- 5 engaging social media post ideas + Canva prompts.  
- Website homepage mockup copy.  
- Blog posts, ad copy, and product descriptions.  
- Content calendar for social media.  

### Phase 3: Client Outreach & Monetization
- Sales strategies for branding assets.  
- Outreach email template.  
- Canva pitch deck prompts.  
- Monetization & pricing strategy.  

---

## 📸 Canva Assets
Logos, social media posts, and pitch deck designs were created using **Canva Magic Media** AI prompts (included in each phase file).  

---

## ✅ Submission Note
This repository represents the complete work for **Assignment 1: Exploring AI with Creativity**.  
